// Example placeholder for future interactivity
document.querySelectorAll('.view-report').forEach(button => {
  button.addEventListener('click', () => {
    alert('Detailed report view coming soon!');
  });
});